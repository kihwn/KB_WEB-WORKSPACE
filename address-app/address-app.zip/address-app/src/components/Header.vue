<template>
  <header>
    <nav>
      <!-- <router-link to="/">Board List</router-link>
      <router-link to="/create">Create New Post</router-link> -->
    </nav>
  </header>
</template>

<script>
export default {
  name: 'Header',
};
</script>

<style scoped>
nav a {
  margin: 0 10px;
}
</style>
